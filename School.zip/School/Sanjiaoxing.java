package test;

import java.util.Scanner;

public class Sanjiaoxing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a,b,c;
		Scanner keyboard=new Scanner(System.in);    //����������������
	     System.out.print("please input a=");
		a=keyboard.nextDouble();
		System.out.print("please input b=");
		b=keyboard.nextDouble();
		System.out.print("please input c=");
		c=keyboard.nextDouble();
       
	}
}
